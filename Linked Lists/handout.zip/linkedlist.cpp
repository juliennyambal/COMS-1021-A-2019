#include "linkedlist.h"

LinkedList::LinkedList()
{
}


void LinkedList::push_front(int value)
{
}

void LinkedList::push_back(int value)
{
}

void LinkedList::pop_front()
{
}

void LinkedList::pop_back()
{
}

void LinkedList::reverse()
{
}

LinkedList *list_union(LinkedList &l1, LinkedList &l2)
{
}
